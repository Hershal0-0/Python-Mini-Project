import kivy
from kivy.app import App
from kivy.uix.label import Label
import datetime as dt
from kivy.clock import Clock 
from kivy.core.audio import SoundLoader
#from kivy.uix.

class MyApp(App):
	def getTime(self):	
		time = str(dt.datetime.now().hour) + ' ' + str(dt.datetime.now().minute) + ' ' + str(dt.datetime.now().second)
		sound = SoundLoader.load('test.wav')
		if sound:
			sound.play()
		return time



	def build(self):
		return Label(text = self.getTime())

#if __name__ == "main":
#	
#	MyApp().run()

MyApp().run()